const registerForm = document.getElementById('registerForm');
const authMessage = document.getElementById('authMessage');

const showMessage = (text, isError = true) => {
  authMessage.textContent = text;
  authMessage.style.color = isError ? '#b3261e' : '#1f7a1f';
};

registerForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const formData = new FormData(registerForm);
  const payload = {
    name: String(formData.get('name') || '').trim(),
    restaurantName: String(formData.get('restaurantName') || '').trim(),
    location: String(formData.get('location') || '').trim(),
    email: String(formData.get('email') || '').trim(),
    password: String(formData.get('password') || ''),
  };

  try {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await response.json();
    if (!response.ok) {
      showMessage(data.error || 'Registration failed');
      return;
    }

    showMessage('Registration successful. Redirecting to login...', false);
    setTimeout(() => {
      window.location.href = '/login.html';
    }, 700);
  } catch (_error) {
    showMessage('Unable to reach server');
  }
});
