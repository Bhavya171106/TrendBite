const API_KEY = process.env.API_KEY;

module.exports = (req, res, next) => {
  if (!API_KEY) {
    return res.status(500).json({
      error: 'Server API key is not configured. Set API_KEY in .env.',
    });
  }

  const clientKey = req.header('x-api-key');
  if (!clientKey) {
    return res.status(401).json({ error: 'Missing x-api-key header' });
  }

  if (clientKey !== API_KEY) {
    return res.status(403).json({ error: 'Invalid API key' });
  }

  return next();
};
