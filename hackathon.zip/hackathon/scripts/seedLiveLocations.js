require('dotenv').config();
const liveDataService = require('../services/liveDataService');

const rowsPerLocation = Number(process.argv[2] || 18);

liveDataService
  .seedLiveData(rowsPerLocation)
  .then((result) => {
    console.log('Live location seed completed:', result);
    process.exit(0);
  })
  .catch((error) => {
    console.error('Live location seed failed:', error.message);
    process.exit(1);
  });
