const fs = require('fs');
const csv = require('csv-parser');
const foodService = require('../services/foodService');
const analyticsService = require('../services/analyticsService');
const aiService = require('../services/aiService');
const liveDataService = require('../services/liveDataService');

exports.addFoodPost = async (req, res) => {
  try {
    const payload = req.body;
    const required = ['food', 'ingredient1', 'ingredient2', 'day', 'location'];

    for (const key of required) {
      if (!payload[key]) {
        return res.status(400).json({ error: `Missing required field: ${key}` });
      }
    }

    const created = await foodService.insertFoodPost(payload);
    return res.status(201).json({ message: 'Food post added', data: created });
  } catch (error) {
    console.error('addFoodPost error:', error);
    return res.status(500).json({ error: 'Failed to add food post' });
  }
};

exports.ingestCsv = async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'CSV file is required' });
  }

  const rows = [];

  try {
    await new Promise((resolve, reject) => {
      fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (data) => rows.push(data))
        .on('end', resolve)
        .on('error', reject);
    });

    const normalizedRows = rows.map((row) => ({
      food: row.food,
      ingredient1: row.ingredient1,
      ingredient2: row.ingredient2,
      day: row.day,
      location: row.location,
      timestamp: row.timestamp,
    }));

    const inserted = await foodService.bulkInsertFoodPosts(normalizedRows);

    fs.unlink(req.file.path, () => {});

    return res.json({
      message: 'CSV ingestion completed',
      receivedRows: rows.length,
      insertedRows: inserted,
    });
  } catch (error) {
    console.error('ingestCsv error:', error);
    fs.unlink(req.file.path, () => {});
    return res.status(500).json({ error: 'Failed to ingest CSV' });
  }
};

exports.getDashboard = async (req, res) => {
  try {
    const location = req.query.location || null;

    const trendingFoods = await analyticsService.getTrendingFoods(location);
    const weekendDemand = await analyticsService.getWeekendDemand(location);
    const locationTrends = await analyticsService.getLocationBasedTrends(location);
    const growthPercentage = await analyticsService.getGrowthPercentage(location);
    const revenuePrediction = analyticsService.predictRevenueBoost({
      trendingFoods,
      weekendDemand,
    });

    const aiRecommendations = aiService.generateWeekendSpecials({
      trendingFoods,
      location,
    });

    return res.json({
      filters: { location },
      trendingFoods,
      weekendDemand,
      locationTrends,
      growthPercentage,
      revenuePrediction,
      aiRecommendations,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error('getDashboard error:', error);
    return res.status(500).json({ error: 'Failed to load dashboard analytics' });
  }
};

exports.getLocations = async (_req, res) => {
  try {
    const locations = await analyticsService.getAvailableLocations();
    return res.json({ locations });
  } catch (error) {
    console.error('getLocations error:', error);
    return res.status(500).json({ error: 'Failed to fetch locations' });
  }
};

exports.seedLiveLocations = async (req, res) => {
  try {
    const rowsPerLocation = Number(req.body.rowsPerLocation || 18);
    const result = await liveDataService.seedLiveData(rowsPerLocation);
    return res.json({
      message: 'Live location data seeded successfully',
      ...result,
    });
  } catch (error) {
    console.error('seedLiveLocations error:', error);
    return res.status(500).json({ error: 'Failed to seed live location data' });
  }
};
