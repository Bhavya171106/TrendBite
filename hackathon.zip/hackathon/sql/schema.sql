CREATE DATABASE IF NOT EXISTS food_trend_agent;
USE food_trend_agent;

CREATE TABLE IF NOT EXISTS food_posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  food VARCHAR(100) NOT NULL,
  ingredient1 VARCHAR(100) NOT NULL,
  ingredient2 VARCHAR(100) NOT NULL,
  day VARCHAR(20) NOT NULL,
  location VARCHAR(100) NOT NULL,
  timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_location (location),
  INDEX idx_day (day),
  INDEX idx_food (food),
  INDEX idx_timestamp (timestamp)
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  restaurant_name VARCHAR(160) NOT NULL,
  location VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  password_salt VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_email (email),
  INDEX idx_users_location (location)
);
