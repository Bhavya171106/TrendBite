const express = require('express');
const multer = require('multer');
const foodController = require('../controllers/foodController');
const apiKeyAuth = require('../middleware/apiKeyAuth');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/add-food', apiKeyAuth, foodController.addFoodPost);
router.post('/ingest-csv', apiKeyAuth, upload.single('file'), foodController.ingestCsv);
router.post('/seed-live-locations', apiKeyAuth, foodController.seedLiveLocations);
router.get('/dashboard', apiKeyAuth, foodController.getDashboard);
router.get('/locations', apiKeyAuth, foodController.getLocations);

module.exports = router;
