const crypto = require('crypto');
const db = require('../db');

const ITERATIONS = 100000;
const KEY_LENGTH = 64;
const DIGEST = 'sha512';

const hashPassword = (password, salt = crypto.randomBytes(16).toString('hex')) => {
  const hash = crypto.pbkdf2Sync(password, salt, ITERATIONS, KEY_LENGTH, DIGEST).toString('hex');
  return { salt, hash };
};

const verifyPassword = (password, salt, hash) => {
  const candidate = crypto
    .pbkdf2Sync(password, salt, ITERATIONS, KEY_LENGTH, DIGEST)
    .toString('hex');
  return crypto.timingSafeEqual(Buffer.from(candidate, 'hex'), Buffer.from(hash, 'hex'));
};

exports.createUser = async ({ name, email, password, restaurantName, location }) => {
  const { salt, hash } = hashPassword(password);
  const sql = `
    INSERT INTO users (name, restaurant_name, location, email, password_hash, password_salt)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  const [result] = await db.execute(sql, [
    name,
    restaurantName,
    location,
    email.toLowerCase(),
    hash,
    salt,
  ]);
  return {
    id: result.insertId,
    name,
    restaurantName,
    location,
    email: email.toLowerCase(),
  };
};

exports.findUserByEmail = async (email) => {
  const sql = `
    SELECT id, name, restaurant_name, location, email, password_hash, password_salt, created_at
    FROM users
    WHERE email = ?
    LIMIT 1
  `;
  const [rows] = await db.execute(sql, [email.toLowerCase()]);
  return rows[0] || null;
};

exports.checkPassword = verifyPassword;
